====================================================
ПРЕФИКСЫ-ПЛАШКИ — RESOURCE PACK (Minecraft 1.20.1)
====================================================

ЧТО ВНУТРИ
----------
Ресурспак заменяет 14 непечатаемых unicode-символов (E001–E00E)
на PNG-картинки с плашками привилегий:

  \uE001  →  PLAYER        (серый)
  \uE002  →  TRUE          (светло-зелёный)
  \uE003  →  ORBIT         (голубой)
  \uE004  →  META          (светло-красный)
  \uE005  →  QUARK         (фиолетовый)
  \uE006  →  HOLE          (тёмно-серый, темнее PLAYER)
  \uE007  →  QUASAR        (тёмно-красный)
  \uE008  →  ML.MODERATOR  (светло-оранжевый)
  \uE009  →  MODERATOR     (тёмно-синий)
  \uE00A  →  HELPER        (жёлтый)
  \uE00B  →  MEDIA         (белый)
  \uE00C  →  OWNER         (чёрный)
  \uE00D  →  TECH.ADMIN    (бордовый)
  \uE00E  →  ADMIN         (тёмно-оранжевый)

УСТАНОВКА РЕСУРСПАКА ИГРОКАМ
-----------------------------
1. Заархивируй содержимое папки rp (не саму папку, а файлы внутри неё:
   pack.mcmeta и assets/) в .zip — например privilege-pack.zip
2. Залей .zip на файлообменник (или на сайт сервера) и пропиши в
   server.properties:
       resource-pack=https://ссылка-на-твой-pack.zip
       resource-pack-sha1=<sha1 хэш файла>
   Хэш можно получить командой: sha1sum privilege-pack.zip
3. Либо сделай его "required" через resource-pack-prompt-message,
   чтобы игроки не могли зайти без установки пака (важно, иначе
   часть игроков не увидит плашки и вместо них будут видны кракозябры).

КАК ВСТАВИТЬ СИМВОЛ В ПРЕФИКС (LuckPerms + любой чат-плагин)
--------------------------------------------------------------
В LuckPerms префикс прописывается как обычный текст с приватным
unicode-символом внутри. Пример команды для группы "true":

    /lp group true meta setprefix "&r\uE002&r "

В конфиге плагина чата (EssentialsX, ChatManager, VentureChat и т.д.)
формат префикса обычно берётся из LuckPerms автоматически через
PlaceholderAPI (%luckperms_prefix%). Просто пропиши символ прямо в
префикс группы — он подставится вместо плейсхолдера как обычный текст.

Если плагин не поддерживает вставку через команду напрямую (не даёт
ввести \uE002), используй один из вариантов:
  а) Открой config.yml нужного плагина в текстовом редакторе с
     поддержкой Unicode (Notepad++, VS Code) и вставь символ вручную,
     скопировав его из таблицы выше (символы приватной зоны Unicode
     не отображаются как текст, но копируются как есть).
  б) Используй плагин типа TAB или NameTagEdit, где можно прописать
     figure prefix через raw JSON текст с escape-последовательностью
     \uE001 и т.д.

ВАЖНО
-----
- Игроки БЕЗ установленного ресурспака увидят на месте плашки either
  пустой квадрат, либо ничего — поэтому пак нужно делать обязательным
  (resource-pack-prompt-message + запрет захода без принятия).
- pack_format 15 соответствует версии 1.20.1. Если апгрейднешь сервер
  на более новую версию Minecraft, возможно потребуется поднять
  pack_format в pack.mcmeta.
- Если захочешь добавить новую привилегию — просто добавь новый PNG
  в assets/minecraft/textures/font/, пропиши новый провайдер bitmap
  в assets/minecraft/font/default.json с новым свободным символом
  (например \uE008) и используй его в префиксе.

ФАЙЛЫ ПЛАШЕК (можно редактировать/перекрашивать отдельно)
-----------------------------------------------------------
assets/minecraft/textures/font/player.png
assets/minecraft/textures/font/true.png
assets/minecraft/textures/font/orbit.png
assets/minecraft/textures/font/meta.png
assets/minecraft/textures/font/quark.png
assets/minecraft/textures/font/hole.png
assets/minecraft/textures/font/quasar.png
assets/minecraft/textures/font/ml_moderator.png
assets/minecraft/textures/font/moderator.png
assets/minecraft/textures/font/helper.png
assets/minecraft/textures/font/media.png
assets/minecraft/textures/font/owner.png
assets/minecraft/textures/font/tech_admin.png
assets/minecraft/textures/font/admin.png
