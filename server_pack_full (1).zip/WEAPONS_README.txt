====================================================
ДОБАВЛЕННОЕ ОРУЖИЕ (CIT, требует OptiFine / Iris+Sodium+Continuity)
====================================================

Как это работает:
Возьми любой меч или топор (wooden/stone/iron/golden/diamond/netherite),
переименуй его в наковальне так, чтобы название СОДЕРЖАЛО указанное
ниже слово (регистр и точный текст важны для некоторых) — и клиент
с ресурспаком покажет вместо ванильной модели кастомную 3D-текстуру.

Игрок БЕЗ OptiFine/Iris увидит обычный ванильный меч — сама текстура/
модель предмета при этом не меняется, различия чисто визуальные и
только на клиенте с поддержкой CIT.

КОСЫ (7 шт.)
------------
"katana"                -> Katana (можно писать просто как часть названия)
"crescent rose"          -> Crescent Rose
"divine reaper"          -> Divine Reaper
"abominable scythe"      -> Abominable Scythe
"frost scythe"           -> Frost Scythe
"wraith scythe"          -> Green/Wraith Scythe
"magiscythe"             -> Magiscythe
"sculk scythe"           -> Sculk Scythe

МЕЧИ (14 шт.)
-------------
"abominable blade"       -> Abominable Blade
"abominable greatsaber"  -> Abominable Greatsaber
"Aquantic Sacred Blade"  -> Aquantic Sacred Blade
"ocean rage"             -> Aquantic Trident (Ocean Rage)
"cyber katana"           -> Cyber Katana
"cybernetic katana"      -> Cybernetic Katana
"masamune"               -> Masamune
"divine justice"         -> Divine Justice
"divine punisher"        -> Divine Punisher
"molten sword"           -> Molten Sword
"Molten Blade"           -> Molten Blade
"sunbreak"               -> Sunbreak
"hero sword"             -> Hero Sword
"yoru"                   -> Yoru

ПРИМЕР
------
1. Взять железный меч, положить в наковальню
2. Вписать имя, например: "Yoru"
3. Забрать предмет — у игроков с OptiFine/Iris он будет отображаться
   как чёрный длинный меч Yoru вместо обычного iron_sword

ВАЖНО
-----
- Пак совмещён с твоим паком плашек привилегий (файлы шрифта не
  затронуты, конфликтов нет — разные папки: font/ и optifine/cit/).
- pack_format = 15 (совместимо с 1.20.1).
- Названия в кавычках выше — это подстрока (ipattern), т.е. можно
  дописывать что угодно вокруг, главное чтобы указанный кусок текста
  входил в название целиком (например "Мой Yoru" тоже сработает).
- Если хочешь другие 20-30 клинков/кос из полного пака (в нём их 120) —
  просто скажи, добавлю ещё.
